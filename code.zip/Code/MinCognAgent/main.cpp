#include <iostream>
#include "evoalgs.h"
#include <ctime>
#include <cstdlib>

using namespace std;

int main(){
	srand((unsigned)time(0)); 
	evoalgs evolutionaryAlgorithm;
	return 0;
}